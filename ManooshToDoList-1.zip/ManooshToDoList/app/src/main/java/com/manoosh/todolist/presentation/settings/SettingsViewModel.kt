package com.manoosh.todolist.presentation.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.manoosh.todolist.domain.model.AccentColor
import com.manoosh.todolist.domain.model.AppBackground
import com.manoosh.todolist.domain.model.AppFont
import com.manoosh.todolist.domain.model.ManooshThemeModeSetting
import com.manoosh.todolist.domain.model.UserSettings
import com.manoosh.todolist.domain.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    val settings: StateFlow<UserSettings> = settingsRepository.observeSettings()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UserSettings())

    fun onThemeModeSelected(mode: ManooshThemeModeSetting) = viewModelScope.launch {
        settingsRepository.setThemeMode(mode)
    }

    fun onAccentColorSelected(color: AccentColor) = viewModelScope.launch {
        settingsRepository.setAccentColor(color)
    }

    fun onFontSelected(font: AppFont) = viewModelScope.launch {
        settingsRepository.setFont(font)
    }

    fun onBackgroundSelected(background: AppBackground) = viewModelScope.launch {
        settingsRepository.setBackground(background)
    }

    fun onNotificationSoundToggled(enabled: Boolean) = viewModelScope.launch {
        settingsRepository.setNotificationSound(enabled)
    }

    fun onNotificationVibrationToggled(enabled: Boolean) = viewModelScope.launch {
        settingsRepository.setNotificationVibration(enabled)
    }

    fun onAnimationsToggled(enabled: Boolean) = viewModelScope.launch {
        settingsRepository.setAnimationsEnabled(enabled)
    }

    fun onDynamicColorToggled(enabled: Boolean) = viewModelScope.launch {
        settingsRepository.setDynamicColorEnabled(enabled)
    }
}
