package com.manoosh.todolist.domain.model

import androidx.compose.ui.graphics.Color

enum class AccentColor(val label: String, val color: Color) {
    BLUE("Blue", Color(0xFF3D5AFE)),
    PURPLE("Purple", Color(0xFF7C4DFF)),
    GREEN("Green", Color(0xFF43A047)),
    RED("Red", Color(0xFFE53935)),
    ORANGE("Orange", Color(0xFFFB8C00)),
    PINK("Pink", Color(0xFFEC407A)),
    TEAL("Teal", Color(0xFF00897B)),
    BROWN("Brown", Color(0xFF6D4C41)),
    INDIGO("Indigo", Color(0xFF3949AB))
}

enum class AppFont(val label: String) {
    ROBOTO("Roboto"),
    POPPINS("Poppins"),
    MONTSERRAT("Montserrat"),
    INTER("Inter"),
    NUNITO("Nunito"),
    CAIRO("Cairo"),
    TAJAWAL("Tajawal")
}

enum class AppBackground(val label: String) {
    SOLID("Solid"),
    GRADIENT("Gradient"),
    GLASS("Glass"),
    BLUR("Blur"),
    NATURE("Nature"),
    ABSTRACT("Abstract"),
    MINIMAL("Minimal"),
    CUSTOM_IMAGE("Custom Image")
}

/** Aggregate of every user-configurable preference, persisted via DataStore. */
data class UserSettings(
    val themeMode: ManooshThemeModeSetting = ManooshThemeModeSetting.SYSTEM,
    val accentColor: AccentColor = AccentColor.BLUE,
    val font: AppFont = AppFont.ROBOTO,
    val background: AppBackground = AppBackground.SOLID,
    val customBackgroundImageUri: String? = null,
    val notificationSoundEnabled: Boolean = true,
    val notificationVibrationEnabled: Boolean = true,
    val animationsEnabled: Boolean = true,
    val dynamicColorEnabled: Boolean = true,
    val languageTag: String = "en"
)

enum class ManooshThemeModeSetting { LIGHT, DARK, SYSTEM, AMOLED }
