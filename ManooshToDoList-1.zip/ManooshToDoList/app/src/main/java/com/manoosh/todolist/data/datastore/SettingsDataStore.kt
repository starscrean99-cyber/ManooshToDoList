package com.manoosh.todolist.data.datastore

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore

val android.content.Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "manoosh_settings"
)
