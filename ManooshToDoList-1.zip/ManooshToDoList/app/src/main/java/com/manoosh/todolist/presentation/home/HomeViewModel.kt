package com.manoosh.todolist.presentation.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.manoosh.todolist.domain.model.Priority
import com.manoosh.todolist.domain.model.Task
import com.manoosh.todolist.domain.usecase.category.CategoryUseCases
import com.manoosh.todolist.domain.usecase.task.TaskUseCases
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val taskUseCases: TaskUseCases,
    private val categoryUseCases: CategoryUseCases
) : ViewModel() {

    private val searchQuery = MutableStateFlow("")
    private val activeFilter = MutableStateFlow(TaskFilter.ALL)
    private val activeSort = MutableStateFlow(TaskSort.NEWEST)
    private val recentlyDeleted = MutableStateFlow<Task?>(null)

    val uiState: StateFlow<HomeUiState> = combine(
        taskUseCases.observeTasks(),
        categoryUseCases.observeCategories(),
        searchQuery,
        activeFilter,
        activeSort
    ) { tasks, categories, query, filter, sort ->
        val nonArchived = tasks.filter { !it.isArchived }
        val filtered = applyFilter(nonArchived, filter)
        val searched = applySearch(filtered, query, categories)
        val sorted = applySort(searched, sort)
        HomeUiState(
            isLoading = false,
            allTasks = nonArchived,
            visibleTasks = sorted,
            categories = categories,
            searchQuery = query,
            activeFilter = filter,
            activeSort = sort,
            recentlyDeleted = recentlyDeleted.value
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = HomeUiState()
    )

    fun onSearchQueryChanged(query: String) {
        searchQuery.value = query
    }

    fun onFilterSelected(filter: TaskFilter) {
        activeFilter.value = filter
    }

    fun onSortSelected(sort: TaskSort) {
        activeSort.value = sort
    }

    fun onToggleCompleted(task: Task) = viewModelScope.launch {
        taskUseCases.toggleTaskCompleted(task.id, !task.isCompleted)
    }

    fun onToggleFavorite(task: Task) = viewModelScope.launch {
        taskUseCases.toggleTaskFavorite(task.id, !task.isFavorite)
    }

    fun onDeleteTask(task: Task) = viewModelScope.launch {
        taskUseCases.deleteTask(task)
        recentlyDeleted.value = task
    }

    fun onUndoDelete() = viewModelScope.launch {
        recentlyDeleted.value?.let { taskUseCases.addOrUpdateTask(it.copy(id = 0L)) }
        recentlyDeleted.value = null
    }

    fun onArchiveTask(task: Task) = viewModelScope.launch {
        taskUseCases.archiveTask(task.id, true)
    }

    private fun applyFilter(tasks: List<Task>, filter: TaskFilter): List<Task> {
        val today = LocalDate.now()
        return when (filter) {
            TaskFilter.ALL -> tasks
            TaskFilter.TODAY -> tasks.filter { it.reminderDate == today }
            TaskFilter.TOMORROW -> tasks.filter { it.reminderDate == today.plusDays(1) }
            TaskFilter.THIS_WEEK -> tasks.filter {
                it.reminderDate != null &&
                    !it.reminderDate.isBefore(today) &&
                    it.reminderDate.isBefore(today.plusDays(7))
            }
            TaskFilter.COMPLETED -> tasks.filter { it.isCompleted }
            TaskFilter.PENDING -> tasks.filter { !it.isCompleted }
            TaskFilter.FAVORITES -> tasks.filter { it.isFavorite }
            TaskFilter.HIGH_PRIORITY -> tasks.filter {
                it.priority == Priority.HIGH || it.priority == Priority.CRITICAL
            }
        }
    }

    private fun applySearch(
        tasks: List<Task>,
        query: String,
        categories: List<com.manoosh.todolist.domain.model.Category>
    ): List<Task> {
        if (query.isBlank()) return tasks
        val q = query.trim().lowercase()
        val categoryNamesById = categories.associateBy({ it.id }, { it.name.lowercase() })
        return tasks.filter { task ->
            task.title.lowercase().contains(q) ||
                task.description.lowercase().contains(q) ||
                (task.categoryId?.let { categoryNamesById[it]?.contains(q) } == true)
        }
    }

    private fun applySort(tasks: List<Task>, sort: TaskSort): List<Task> = when (sort) {
        TaskSort.NEWEST -> tasks.sortedByDescending { it.createdAt }
        TaskSort.OLDEST -> tasks.sortedBy { it.createdAt }
        TaskSort.ALPHABETICAL -> tasks.sortedBy { it.title.lowercase() }
        TaskSort.REMINDER_TIME -> tasks.sortedWith(
            compareBy(nullsLast()) { it.reminderDateTime }
        )
        TaskSort.PRIORITY -> tasks.sortedByDescending { it.priority.weight }
    }
}
