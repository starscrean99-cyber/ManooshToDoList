package com.manoosh.todolist.presentation.navigation

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object AddTask : Screen("add_task")
    data object EditTask : Screen("edit_task/{taskId}") {
        fun createRoute(taskId: Long) = "edit_task/$taskId"
    }

    // Reserved for upcoming phases:
    data object Statistics : Screen("statistics")
    data object Settings : Screen("settings")
    data object Archive : Screen("archive")
    data object Search : Screen("search")
}
