package com.manoosh.todolist.presentation.statistics.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val PieColors = listOf(
    Color(0xFF3D5AFE), Color(0xFF00BFA5), Color(0xFFFFAB00),
    Color(0xFFE53935), Color(0xFF8E24AA), Color(0xFF43A047),
    Color(0xFFEC407A), Color(0xFF6D4C41), Color(0xFF00ACC1)
)

/** Simple pie chart with a legend; no external charting library required. */
@Composable
fun PieChart(
    data: Map<String, Int>,
    modifier: Modifier = Modifier
) {
    if (data.isEmpty() || data.values.all { it == 0 }) return
    val total = data.values.sum().toFloat()
    val slices = data.entries.toList()

    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        Canvas(modifier = Modifier.size(140.dp)) {
            var startAngle = -90f
            slices.forEachIndexed { index, entry ->
                val sweep = (entry.value / total) * 360f
                drawArc(
                    color = PieColors[index % PieColors.size],
                    startAngle = startAngle,
                    sweepAngle = sweep,
                    useCenter = true
                )
                startAngle += sweep
            }
        }
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            slices.forEachIndexed { index, entry ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                    ) {
                        Canvas(modifier = Modifier.size(10.dp)) {
                            drawCircle(color = PieColors[index % PieColors.size])
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${entry.key} (${entry.value})",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
            }
        }
    }
}
