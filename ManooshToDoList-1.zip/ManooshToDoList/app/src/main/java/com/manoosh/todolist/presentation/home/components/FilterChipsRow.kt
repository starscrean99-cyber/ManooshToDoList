package com.manoosh.todolist.presentation.home.components

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import com.manoosh.todolist.presentation.home.TaskFilter

private val filterLabels = mapOf(
    TaskFilter.ALL to "All",
    TaskFilter.TODAY to "Today",
    TaskFilter.TOMORROW to "Tomorrow",
    TaskFilter.THIS_WEEK to "This Week",
    TaskFilter.COMPLETED to "Completed",
    TaskFilter.PENDING to "Pending",
    TaskFilter.FAVORITES to "Favorites",
    TaskFilter.HIGH_PRIORITY to "High Priority"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilterChipsRow(
    activeFilter: TaskFilter,
    onFilterSelected: (TaskFilter) -> Unit
) {
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp)) {
        items(TaskFilter.entries) { filter ->
            FilterChip(
                modifier = androidx.compose.ui.Modifier.padding(end = 8.dp),
                selected = filter == activeFilter,
                onClick = { onFilterSelected(filter) },
                label = { Text(filterLabels[filter] ?: filter.name) }
            )
        }
    }
}
