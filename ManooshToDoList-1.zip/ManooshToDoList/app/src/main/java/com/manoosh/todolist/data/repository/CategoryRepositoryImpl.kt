package com.manoosh.todolist.data.repository

import com.manoosh.todolist.data.local.dao.CategoryDao
import com.manoosh.todolist.data.mapper.toDomain
import com.manoosh.todolist.data.mapper.toEntity
import com.manoosh.todolist.domain.model.Category
import com.manoosh.todolist.domain.model.DefaultCategories
import com.manoosh.todolist.domain.repository.CategoryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CategoryRepositoryImpl @Inject constructor(
    private val dao: CategoryDao
) : CategoryRepository {

    override fun observeCategories(): Flow<List<Category>> =
        dao.observeAll().map { list -> list.map { it.toDomain() } }

    override suspend fun getCategoryById(id: Long): Category? = dao.getById(id)?.toDomain()

    override suspend fun upsertCategory(category: Category): Long = dao.upsert(category.toEntity())

    override suspend fun deleteCategory(category: Category) = dao.delete(category.toEntity())

    override suspend fun seedDefaultsIfEmpty() {
        if (dao.count() == 0) {
            dao.insertAll(DefaultCategories.seed.map { it.toEntity() })
        }
    }
}
