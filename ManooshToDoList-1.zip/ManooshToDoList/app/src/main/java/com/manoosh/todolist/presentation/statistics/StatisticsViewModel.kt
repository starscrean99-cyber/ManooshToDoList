package com.manoosh.todolist.presentation.statistics

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.manoosh.todolist.domain.usecase.category.CategoryUseCases
import com.manoosh.todolist.domain.usecase.task.TaskUseCases
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import java.time.LocalDate
import javax.inject.Inject

@HiltViewModel
class StatisticsViewModel @Inject constructor(
    taskUseCases: TaskUseCases,
    categoryUseCases: CategoryUseCases
) : ViewModel() {

    val uiState: StateFlow<StatisticsUiState> = combine(
        taskUseCases.observeTasks(),
        categoryUseCases.observeCategories()
    ) { tasks, categories ->
        val nonArchived = tasks.filter { !it.isArchived }
        val completed = nonArchived.count { it.isCompleted }
        val total = nonArchived.size
        val today = LocalDate.now()
        val categoryNameById = categories.associateBy({ it.id }, { it.name })

        val categoryBreakdown = nonArchived
            .groupBy { categoryNameById[it.categoryId] ?: "Uncategorized" }
            .mapValues { it.value.size }

        val priorityBreakdown = nonArchived
            .groupBy { it.priority.label }
            .mapValues { it.value.size }

        val last7Days = (6 downTo 0).map { offset ->
            val day = today.minusDays(offset.toLong())
            DailyCount(
                date = day,
                completed = nonArchived.count { it.isCompleted && it.updatedAt.toLocalDate() == day },
                created = nonArchived.count { it.createdAt.toLocalDate() == day }
            )
        }

        val last30DaysTasks = nonArchived.filter {
            !it.createdAt.toLocalDate().isBefore(today.minusDays(30))
        }
        val last30Rate = if (last30DaysTasks.isNotEmpty()) {
            (last30DaysTasks.count { it.isCompleted } * 100) / last30DaysTasks.size
        } else 0

        StatisticsUiState(
            isLoading = false,
            totalTasks = total,
            completedTasks = completed,
            pendingTasks = total - completed,
            completionPercentage = if (total > 0) (completed * 100) / total else 0,
            todayTasks = nonArchived.count { it.reminderDate == today },
            categoryBreakdown = categoryBreakdown,
            priorityBreakdown = priorityBreakdown,
            last7Days = last7Days,
            last30DaysCompletionRate = last30Rate
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), StatisticsUiState())
}
