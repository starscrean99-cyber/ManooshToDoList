package com.manoosh.todolist.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.manoosh.todolist.data.local.dao.CategoryDao
import com.manoosh.todolist.data.local.dao.TaskDao
import com.manoosh.todolist.data.local.entity.CategoryEntity
import com.manoosh.todolist.data.local.entity.TaskEntity

@Database(
    entities = [TaskEntity::class, CategoryEntity::class],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
    abstract fun categoryDao(): CategoryDao

    companion object {
        const val DATABASE_NAME = "manoosh_todolist.db"

        // Placeholder for the next migration, e.g.:
        // val MIGRATION_1_2 = object : Migration(1, 2) {
        //     override fun migrate(db: SupportSQLiteDatabase) { ... }
        // }
    }
}
