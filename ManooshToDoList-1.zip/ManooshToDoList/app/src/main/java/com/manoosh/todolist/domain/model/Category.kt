package com.manoosh.todolist.domain.model

/**
 * A task category. The nine defaults are seeded on first launch;
 * users can add unlimited custom categories (isCustom = true) which
 * can be deleted, unlike the defaults.
 */
data class Category(
    val id: Long = 0L,
    val name: String,
    val colorHex: String,
    val iconName: String,
    val isCustom: Boolean = false
)

object DefaultCategories {
    val seed = listOf(
        Category(name = "Personal", colorHex = "#5C6BC0", iconName = "person"),
        Category(name = "Work", colorHex = "#42A5F5", iconName = "work"),
        Category(name = "Study", colorHex = "#26A69A", iconName = "school"),
        Category(name = "Shopping", colorHex = "#EC407A", iconName = "shopping_cart"),
        Category(name = "Family", colorHex = "#FFA726", iconName = "family_restroom"),
        Category(name = "Health", colorHex = "#EF5350", iconName = "favorite"),
        Category(name = "Finance", colorHex = "#66BB6A", iconName = "attach_money"),
        Category(name = "Travel", colorHex = "#29B6F6", iconName = "flight"),
        Category(name = "Ideas", colorHex = "#AB47BC", iconName = "lightbulb")
    )
}
