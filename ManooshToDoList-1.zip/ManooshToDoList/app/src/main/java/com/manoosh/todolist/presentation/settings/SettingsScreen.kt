package com.manoosh.todolist.presentation.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.manoosh.todolist.domain.model.AccentColor
import com.manoosh.todolist.domain.model.AppBackground
import com.manoosh.todolist.domain.model.AppFont
import com.manoosh.todolist.domain.model.ManooshThemeModeSetting

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(28.dp)
        ) {
            item {
                SettingsSection(title = "Theme") {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ManooshThemeModeSetting.entries.forEach { mode ->
                            FilterChip(
                                selected = settings.themeMode == mode,
                                onClick = { viewModel.onThemeModeSelected(mode) },
                                label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) }
                            )
                        }
                    }
                }
            }

            item {
                SettingsSection(title = "Accent Color") {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        AccentColor.entries.forEach { accent ->
                            ColorSwatch(
                                color = accent.color,
                                selected = settings.accentColor == accent,
                                onClick = { viewModel.onAccentColorSelected(accent) }
                            )
                        }
                    }
                }
            }

            item {
                SettingsSection(title = "Font") {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AppFont.entries.forEach { font ->
                            FilterChip(
                                selected = settings.font == font,
                                onClick = { viewModel.onFontSelected(font) },
                                label = { Text(font.label) }
                            )
                        }
                    }
                }
            }

            item {
                SettingsSection(title = "Background") {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AppBackground.entries.forEach { bg ->
                            FilterChip(
                                selected = settings.background == bg,
                                onClick = { viewModel.onBackgroundSelected(bg) },
                                label = { Text(bg.label) }
                            )
                        }
                    }
                }
            }

            item {
                SettingsSection(title = "Notifications") {
                    SettingsSwitchRow(
                        label = "Sound",
                        checked = settings.notificationSoundEnabled,
                        onCheckedChange = viewModel::onNotificationSoundToggled
                    )
                    SettingsSwitchRow(
                        label = "Vibration",
                        checked = settings.notificationVibrationEnabled,
                        onCheckedChange = viewModel::onNotificationVibrationToggled
                    )
                }
            }

            item {
                SettingsSection(title = "Appearance") {
                    SettingsSwitchRow(
                        label = "Animations",
                        checked = settings.animationsEnabled,
                        onCheckedChange = viewModel::onAnimationsToggled
                    )
                    SettingsSwitchRow(
                        label = "Dynamic Color (Material You)",
                        checked = settings.dynamicColorEnabled,
                        onCheckedChange = viewModel::onDynamicColorToggled
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column {
        Text(text = title, style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(12.dp))
        content()
    }
}

@Composable
private fun SettingsSwitchRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun ColorSwatch(color: Color, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(color)
            .then(Modifier)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (selected) {
            Icon(
                imageVector = Icons.Filled.Check,
                contentDescription = "Selected",
                tint = Color.White
            )
        }
    }
}
