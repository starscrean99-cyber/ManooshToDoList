package com.manoosh.todolist.domain.repository

import com.manoosh.todolist.domain.model.AccentColor
import com.manoosh.todolist.domain.model.AppBackground
import com.manoosh.todolist.domain.model.AppFont
import com.manoosh.todolist.domain.model.ManooshThemeModeSetting
import com.manoosh.todolist.domain.model.UserSettings
import kotlinx.coroutines.flow.Flow

interface SettingsRepository {
    fun observeSettings(): Flow<UserSettings>
    suspend fun setThemeMode(mode: ManooshThemeModeSetting)
    suspend fun setAccentColor(color: AccentColor)
    suspend fun setFont(font: AppFont)
    suspend fun setBackground(background: AppBackground, customImageUri: String? = null)
    suspend fun setNotificationSound(enabled: Boolean)
    suspend fun setNotificationVibration(enabled: Boolean)
    suspend fun setAnimationsEnabled(enabled: Boolean)
    suspend fun setDynamicColorEnabled(enabled: Boolean)
    suspend fun setLanguageTag(tag: String)
}
