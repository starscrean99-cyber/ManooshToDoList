package com.manoosh.todolist.presentation.theme

import androidx.compose.ui.graphics.Color

// Default "Blue" accent — Settings (Phase 2) will let users swap this
// palette at runtime via DataStore-backed theme selection.
val ManooshBlue80 = Color(0xFFAFC6FF)
val ManooshBlue40 = Color(0xFF3D5AFE)
val ManooshBlue20 = Color(0xFF001A6E)

val ManooshNeutral99 = Color(0xFFFDFCFF)
val ManooshNeutral95 = Color(0xFFF1F0F4)
val ManooshNeutral20 = Color(0xFF1B1B1F)
val ManooshNeutral10 = Color(0xFF101014)

val ManooshError40 = Color(0xFFBA1A1A)
val ManooshError80 = Color(0xFFFFB4AB)

val SurfaceGlass = Color(0x33FFFFFF)
