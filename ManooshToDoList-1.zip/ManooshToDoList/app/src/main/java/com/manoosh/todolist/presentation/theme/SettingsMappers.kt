package com.manoosh.todolist.presentation.theme

import androidx.compose.ui.text.font.FontFamily
import com.manoosh.todolist.domain.model.AppFont
import com.manoosh.todolist.domain.model.ManooshThemeModeSetting

fun ManooshThemeModeSetting.toPresentation(): ManooshThemeMode = when (this) {
    ManooshThemeModeSetting.LIGHT -> ManooshThemeMode.LIGHT
    ManooshThemeModeSetting.DARK -> ManooshThemeMode.DARK
    ManooshThemeModeSetting.SYSTEM -> ManooshThemeMode.SYSTEM
    ManooshThemeModeSetting.AMOLED -> ManooshThemeMode.AMOLED
}

// Custom font families (Poppins, Montserrat, Inter, Nunito, Cairo, Tajawal)
// resolve to the system default here; drop the matching variable-font
// files into res/font and switch these to FontFamily(Font(R.font.xxx))
// to activate them without touching any other call site.
fun AppFont.toFontFamily(): FontFamily = FontFamily.Default
