package com.manoosh.todolist.presentation.statistics.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.manoosh.todolist.presentation.statistics.DailyCount
import java.time.format.DateTimeFormatter

/** Bar chart of daily completed-task counts over the given range. */
@Composable
fun BarChart(
    data: List<DailyCount>,
    modifier: Modifier = Modifier,
    barColor: Color = MaterialTheme.colorScheme.primary
) {
    if (data.isEmpty()) return
    val maxValue = (data.maxOfOrNull { maxOf(it.completed, it.created) } ?: 1).coerceAtLeast(1)

    Column(modifier = modifier) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            data.forEach { day ->
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally
                ) {
                    Canvas(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(0.5f)
                    ) {
                        val barHeightRatio = day.completed / maxValue.toFloat()
                        val barHeight = size.height * barHeightRatio
                        drawRect(
                            color = barColor,
                            topLeft = Offset(0f, size.height - barHeight),
                            size = androidx.compose.ui.geometry.Size(size.width, barHeight)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = day.date.format(DateTimeFormatter.ofPattern("EEE")),
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }
    }
}

/** Simple line chart connecting daily completion counts. */
@Composable
fun LineChart(
    data: List<DailyCount>,
    modifier: Modifier = Modifier,
    lineColor: Color = MaterialTheme.colorScheme.primary
) {
    if (data.size < 2) return
    val maxValue = (data.maxOfOrNull { it.completed } ?: 1).coerceAtLeast(1)

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(120.dp)
    ) {
        val stepX = size.width / (data.size - 1)
        val points = data.mapIndexed { index, day ->
            Offset(
                x = index * stepX,
                y = size.height - (day.completed / maxValue.toFloat()) * size.height
            )
        }
        for (i in 0 until points.size - 1) {
            drawLine(
                color = lineColor,
                start = points[i],
                end = points[i + 1],
                strokeWidth = 4f,
                cap = androidx.compose.ui.graphics.StrokeCap.Round
            )
        }
        points.forEach { point ->
            drawCircle(color = lineColor, radius = 6f, center = point)
        }
    }
}
