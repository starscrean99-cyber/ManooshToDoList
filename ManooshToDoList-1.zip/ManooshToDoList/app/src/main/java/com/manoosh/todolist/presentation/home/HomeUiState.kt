package com.manoosh.todolist.presentation.home

import com.manoosh.todolist.domain.model.Category
import com.manoosh.todolist.domain.model.Task

enum class TaskFilter {
    ALL, TODAY, TOMORROW, THIS_WEEK, COMPLETED, PENDING, FAVORITES, HIGH_PRIORITY
}

enum class TaskSort {
    NEWEST, OLDEST, ALPHABETICAL, REMINDER_TIME, PRIORITY
}

data class HomeUiState(
    val isLoading: Boolean = true,
    val allTasks: List<Task> = emptyList(),
    val visibleTasks: List<Task> = emptyList(),
    val categories: List<Category> = emptyList(),
    val searchQuery: String = "",
    val activeFilter: TaskFilter = TaskFilter.ALL,
    val activeSort: TaskSort = TaskSort.NEWEST,
    val recentlyDeleted: Task? = null
) {
    val isEmpty: Boolean get() = !isLoading && visibleTasks.isEmpty()
}
