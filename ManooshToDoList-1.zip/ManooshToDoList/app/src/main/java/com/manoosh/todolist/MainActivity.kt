package com.manoosh.todolist

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.manoosh.todolist.presentation.navigation.ManooshNavGraph
import com.manoosh.todolist.presentation.settings.SettingsViewModel
import com.manoosh.todolist.presentation.theme.ManooshTheme
import com.manoosh.todolist.presentation.theme.toFontFamily
import com.manoosh.todolist.presentation.theme.toPresentation
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ManooshApp()
        }
    }
}

@Composable
fun ManooshApp(settingsViewModel: SettingsViewModel = hiltViewModel()) {
    val settings by settingsViewModel.settings.collectAsStateWithLifecycle()

    ManooshTheme(
        themeMode = settings.themeMode.toPresentation(),
        accentColor = settings.accentColor.color,
        fontFamily = settings.font.toFontFamily(),
        dynamicColor = settings.dynamicColorEnabled
    ) {
        Surface(modifier = Modifier.fillMaxSize()) {
            ManooshNavGraph()
        }
    }
}
