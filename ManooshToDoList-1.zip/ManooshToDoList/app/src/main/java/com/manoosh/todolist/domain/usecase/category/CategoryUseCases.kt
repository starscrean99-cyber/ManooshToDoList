package com.manoosh.todolist.domain.usecase.category

import com.manoosh.todolist.domain.model.Category
import com.manoosh.todolist.domain.repository.CategoryRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

data class CategoryUseCases @Inject constructor(
    val observeCategories: ObserveCategoriesUseCase,
    val addOrUpdateCategory: AddOrUpdateCategoryUseCase,
    val deleteCategory: DeleteCategoryUseCase
)

class ObserveCategoriesUseCase @Inject constructor(
    private val repository: CategoryRepository
) {
    operator fun invoke(): Flow<List<Category>> = repository.observeCategories()
}

class AddOrUpdateCategoryUseCase @Inject constructor(
    private val repository: CategoryRepository
) {
    suspend operator fun invoke(category: Category): Result<Long> {
        if (category.name.isBlank()) {
            return Result.failure(IllegalArgumentException("Category name cannot be empty"))
        }
        return runCatching { repository.upsertCategory(category) }
    }
}

class DeleteCategoryUseCase @Inject constructor(
    private val repository: CategoryRepository
) {
    suspend operator fun invoke(category: Category): Result<Unit> {
        if (!category.isCustom) {
            return Result.failure(IllegalStateException("Default categories cannot be deleted"))
        }
        repository.deleteCategory(category)
        return Result.success(Unit)
    }
}
