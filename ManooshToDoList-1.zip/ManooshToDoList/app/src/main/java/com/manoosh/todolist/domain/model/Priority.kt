package com.manoosh.todolist.domain.model

import androidx.compose.ui.graphics.Color

/**
 * The four priority levels a task can carry. `weight` is used for
 * priority-based sorting (higher weight sorts first).
 */
enum class Priority(val label: String, val color: Color, val weight: Int) {
    LOW(label = "Low", color = Color(0xFF4CAF50), weight = 0),
    MEDIUM(label = "Medium", color = Color(0xFFFFC107), weight = 1),
    HIGH(label = "High", color = Color(0xFFFF7043), weight = 2),
    CRITICAL(label = "Critical", color = Color(0xFFE53935), weight = 3)
}
