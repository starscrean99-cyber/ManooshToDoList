package com.manoosh.todolist.presentation.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily

enum class ManooshThemeMode { LIGHT, DARK, SYSTEM, AMOLED }

private val LightColors = lightColorScheme(
    primary = ManooshBlue40,
    onPrimary = Color.White,
    background = ManooshNeutral99,
    surface = ManooshNeutral99,
    error = ManooshError40
)

private val DarkColors = darkColorScheme(
    primary = ManooshBlue80,
    onPrimary = ManooshBlue20,
    background = ManooshNeutral20,
    surface = ManooshNeutral20,
    error = ManooshError80
)

private val AmoledColors = DarkColors.copy(
    background = Color.Black,
    surface = Color.Black
)

@Composable
fun ManooshTheme(
    themeMode: ManooshThemeMode = ManooshThemeMode.SYSTEM,
    accentColor: Color? = null,
    fontFamily: FontFamily = FontFamily.Default,
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val useDark = when (themeMode) {
        ManooshThemeMode.LIGHT -> false
        ManooshThemeMode.DARK, ManooshThemeMode.AMOLED -> true
        ManooshThemeMode.SYSTEM -> systemDark
    }

    val context = LocalContext.current
    var colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (useDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        themeMode == ManooshThemeMode.AMOLED -> AmoledColors
        useDark -> DarkColors
        else -> LightColors
    }

    // A user-selected accent color (from Settings) always overrides the
    // palette's primary, whether or not dynamic color is active.
    if (accentColor != null) {
        colorScheme = colorScheme.copy(primary = accentColor)
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = manooshTypography(fontFamily),
        content = content
    )
}
