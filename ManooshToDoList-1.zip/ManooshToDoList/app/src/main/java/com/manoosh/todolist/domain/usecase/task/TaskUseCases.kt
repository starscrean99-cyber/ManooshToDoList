package com.manoosh.todolist.domain.usecase.task

import com.manoosh.todolist.domain.model.Task
import com.manoosh.todolist.domain.repository.TaskRepository
import kotlinx.coroutines.flow.Flow
import java.time.LocalDateTime
import javax.inject.Inject

/** Bundles every task-related use case so ViewModels take one dependency. */
data class TaskUseCases @Inject constructor(
    val observeTasks: ObserveTasksUseCase,
    val observeTaskById: ObserveTaskByIdUseCase,
    val addOrUpdateTask: AddOrUpdateTaskUseCase,
    val deleteTask: DeleteTaskUseCase,
    val toggleTaskCompleted: ToggleTaskCompletedUseCase,
    val toggleTaskFavorite: ToggleTaskFavoriteUseCase,
    val archiveTask: ArchiveTaskUseCase
)

class ObserveTasksUseCase @Inject constructor(
    private val repository: TaskRepository
) {
    operator fun invoke(): Flow<List<Task>> = repository.observeTasks()
}

class ObserveTaskByIdUseCase @Inject constructor(
    private val repository: TaskRepository
) {
    operator fun invoke(id: Long): Flow<Task?> = repository.observeTaskById(id)
}

/**
 * Validates and persists a new or existing task. Returns a Result so the
 * ViewModel can surface validation errors without throwing.
 */
class AddOrUpdateTaskUseCase @Inject constructor(
    private val repository: TaskRepository
) {
    suspend operator fun invoke(task: Task): Result<Long> {
        if (task.title.isBlank()) {
            return Result.failure(IllegalArgumentException("Task title cannot be empty"))
        }
        if (task.title.length > 200) {
            return Result.failure(IllegalArgumentException("Task title is too long"))
        }
        val toSave = task.copy(updatedAt = LocalDateTime.now())
        return runCatching { repository.upsertTask(toSave) }
    }
}

class DeleteTaskUseCase @Inject constructor(
    private val repository: TaskRepository
) {
    suspend operator fun invoke(task: Task) = repository.deleteTask(task)
}

class ToggleTaskCompletedUseCase @Inject constructor(
    private val repository: TaskRepository
) {
    suspend operator fun invoke(taskId: Long, completed: Boolean) =
        repository.setCompleted(taskId, completed)
}

class ToggleTaskFavoriteUseCase @Inject constructor(
    private val repository: TaskRepository
) {
    suspend operator fun invoke(taskId: Long, favorite: Boolean) =
        repository.setFavorite(taskId, favorite)
}

class ArchiveTaskUseCase @Inject constructor(
    private val repository: TaskRepository
) {
    suspend operator fun invoke(taskId: Long, archived: Boolean) =
        repository.setArchived(taskId, archived)
}
