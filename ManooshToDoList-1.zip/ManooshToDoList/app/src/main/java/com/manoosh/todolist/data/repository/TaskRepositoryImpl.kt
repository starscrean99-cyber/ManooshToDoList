package com.manoosh.todolist.data.repository

import com.manoosh.todolist.data.local.dao.TaskDao
import com.manoosh.todolist.data.mapper.toDomain
import com.manoosh.todolist.data.mapper.toEntity
import com.manoosh.todolist.domain.model.Task
import com.manoosh.todolist.domain.repository.TaskRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.ZoneOffset
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TaskRepositoryImpl @Inject constructor(
    private val dao: TaskDao
) : TaskRepository {

    override fun observeTasks(): Flow<List<Task>> =
        dao.observeAll().map { list -> list.map { it.toDomain() } }

    override fun observeTaskById(id: Long): Flow<Task?> =
        dao.observeById(id).map { it?.toDomain() }

    override suspend fun getTaskById(id: Long): Task? = dao.getById(id)?.toDomain()

    override suspend fun upsertTask(task: Task): Long = dao.upsert(task.toEntity())

    override suspend fun deleteTask(task: Task) = dao.delete(task.toEntity())

    override suspend fun deleteTasks(taskIds: List<Long>) = dao.deleteByIds(taskIds)

    override suspend fun setCompleted(taskId: Long, completed: Boolean) =
        dao.setCompleted(taskId, completed, nowMillis())

    override suspend fun setFavorite(taskId: Long, favorite: Boolean) =
        dao.setFavorite(taskId, favorite, nowMillis())

    override suspend fun setArchived(taskId: Long, archived: Boolean) =
        dao.setArchived(taskId, archived, nowMillis())

    private fun nowMillis(): Long =
        java.time.LocalDateTime.now().atZone(ZoneOffset.systemDefault()).toInstant().toEpochMilli()
}
