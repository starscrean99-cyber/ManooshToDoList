package com.manoosh.todolist.di

import com.manoosh.todolist.data.repository.CategoryRepositoryImpl
import com.manoosh.todolist.data.repository.SettingsRepositoryImpl
import com.manoosh.todolist.data.repository.TaskRepositoryImpl
import com.manoosh.todolist.domain.repository.CategoryRepository
import com.manoosh.todolist.domain.repository.SettingsRepository
import com.manoosh.todolist.domain.repository.TaskRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindTaskRepository(impl: TaskRepositoryImpl): TaskRepository

    @Binds
    @Singleton
    abstract fun bindCategoryRepository(impl: CategoryRepositoryImpl): CategoryRepository

    @Binds
    @Singleton
    abstract fun bindSettingsRepository(impl: SettingsRepositoryImpl): SettingsRepository
}
