package com.manoosh.todolist.presentation.addedittask

import com.manoosh.todolist.domain.model.Category
import com.manoosh.todolist.domain.model.Priority
import com.manoosh.todolist.domain.model.RepeatMode
import java.time.LocalDate
import java.time.LocalTime

data class AddEditTaskUiState(
    val taskId: Long? = null,
    val title: String = "",
    val titleError: String? = null,
    val description: String = "",
    val reminderDate: LocalDate? = null,
    val reminderTime: LocalTime? = null,
    val repeatMode: RepeatMode = RepeatMode.NEVER,
    val priority: Priority = Priority.MEDIUM,
    val categoryId: Long? = null,
    val isFavorite: Boolean = false,
    val categories: List<Category> = emptyList(),
    val isSaving: Boolean = false,
    val isSaved: Boolean = false
) {
    val isEditing: Boolean get() = taskId != null
}
