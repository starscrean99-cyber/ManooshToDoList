package com.manoosh.todolist.presentation.addedittask

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.manoosh.todolist.domain.model.Priority
import com.manoosh.todolist.domain.model.RepeatMode
import com.manoosh.todolist.domain.model.Task
import com.manoosh.todolist.domain.usecase.category.CategoryUseCases
import com.manoosh.todolist.domain.usecase.task.TaskUseCases
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import javax.inject.Inject

@HiltViewModel
class AddEditTaskViewModel @Inject constructor(
    private val taskUseCases: TaskUseCases,
    private val categoryUseCases: CategoryUseCases,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        AddEditTaskUiState(taskId = savedStateHandle.get<Long>("taskId"))
    )
    val uiState: StateFlow<AddEditTaskUiState> = _uiState.asStateFlow()

    init {
        categoryUseCases.observeCategories()
            .onEach { categories -> _uiState.value = _uiState.value.copy(categories = categories) }
            .launchIn(viewModelScope)

        _uiState.value.taskId?.let { id ->
            viewModelScope.launch {
                taskUseCases.observeTaskById(id).onEach { task ->
                    task ?: return@onEach
                    _uiState.value = _uiState.value.copy(
                        title = task.title,
                        description = task.description,
                        reminderDate = task.reminderDate,
                        reminderTime = task.reminderTime,
                        repeatMode = task.repeatMode,
                        priority = task.priority,
                        categoryId = task.categoryId,
                        isFavorite = task.isFavorite
                    )
                }.launchIn(viewModelScope)
            }
        }
    }

    fun onTitleChanged(value: String) {
        _uiState.value = _uiState.value.copy(title = value, titleError = null)
    }

    fun onDescriptionChanged(value: String) {
        _uiState.value = _uiState.value.copy(description = value)
    }

    fun onReminderDateChanged(date: LocalDate?) {
        _uiState.value = _uiState.value.copy(reminderDate = date)
    }

    fun onReminderTimeChanged(time: LocalTime?) {
        _uiState.value = _uiState.value.copy(reminderTime = time)
    }

    fun onRepeatModeChanged(mode: RepeatMode) {
        _uiState.value = _uiState.value.copy(repeatMode = mode)
    }

    fun onPriorityChanged(priority: Priority) {
        _uiState.value = _uiState.value.copy(priority = priority)
    }

    fun onCategoryChanged(categoryId: Long?) {
        _uiState.value = _uiState.value.copy(categoryId = categoryId)
    }

    fun onFavoriteChanged(favorite: Boolean) {
        _uiState.value = _uiState.value.copy(isFavorite = favorite)
    }

    fun onSave() {
        val state = _uiState.value
        if (state.title.isBlank()) {
            _uiState.value = state.copy(titleError = "Title is required")
            return
        }

        _uiState.value = state.copy(isSaving = true)
        viewModelScope.launch {
            val task = Task(
                id = state.taskId ?: 0L,
                title = state.title.trim(),
                description = state.description.trim(),
                reminderDate = state.reminderDate,
                reminderTime = state.reminderTime,
                repeatMode = state.repeatMode,
                priority = state.priority,
                categoryId = state.categoryId,
                isFavorite = state.isFavorite
            )
            val result = taskUseCases.addOrUpdateTask(task)
            result.fold(
                onSuccess = { _uiState.value = _uiState.value.copy(isSaving = false, isSaved = true) },
                onFailure = { error ->
                    _uiState.value = _uiState.value.copy(
                        isSaving = false,
                        titleError = error.message
                    )
                }
            )
        }
    }
}
