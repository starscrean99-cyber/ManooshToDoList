package com.manoosh.todolist.presentation.statistics

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.manoosh.todolist.presentation.statistics.components.BarChart
import com.manoosh.todolist.presentation.statistics.components.LineChart
import com.manoosh.todolist.presentation.statistics.components.PieChart

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatisticsScreen(
    onBack: () -> Unit,
    viewModel: StatisticsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Statistics") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard(label = "Total", value = uiState.totalTasks.toString(), modifier = Modifier.weight(1f))
                    StatCard(label = "Completed", value = uiState.completedTasks.toString(), modifier = Modifier.weight(1f))
                    StatCard(label = "Pending", value = uiState.pendingTasks.toString(), modifier = Modifier.weight(1f))
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard(label = "Completion", value = "${uiState.completionPercentage}%", modifier = Modifier.weight(1f))
                    StatCard(label = "Today", value = uiState.todayTasks.toString(), modifier = Modifier.weight(1f))
                    StatCard(label = "30-Day Rate", value = "${uiState.last30DaysCompletionRate}%", modifier = Modifier.weight(1f))
                }
            }

            item {
                ChartSection(title = "Progress Ring") {
                    ProgressRing(percentage = uiState.completionPercentage)
                }
            }

            item {
                ChartSection(title = "Tasks by Category") {
                    PieChart(data = uiState.categoryBreakdown)
                }
            }

            item {
                ChartSection(title = "Tasks by Priority") {
                    PieChart(data = uiState.priorityBreakdown)
                }
            }

            item {
                ChartSection(title = "Weekly Completions") {
                    BarChart(data = uiState.last7Days)
                }
            }

            item {
                ChartSection(title = "Daily Productivity Trend") {
                    LineChart(data = uiState.last7Days)
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    ElevatedCard(modifier = modifier) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally
        ) {
            Text(text = value, style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = label, style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun ChartSection(title: String, content: @Composable () -> Unit) {
    Column {
        Text(text = title, style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(12.dp))
        content()
    }
}

@Composable
private fun ProgressRing(percentage: Int) {
    Box(contentAlignment = androidx.compose.ui.Alignment.Center) {
        androidx.compose.foundation.Canvas(modifier = Modifier.size(120.dp)) {
            val stroke = 12.dp.toPx()
            drawArc(
                color = androidx.compose.ui.graphics.Color.LightGray.copy(alpha = 0.3f),
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round)
            )
            drawArc(
                color = androidx.compose.ui.graphics.Color(0xFF3D5AFE),
                startAngle = -90f,
                sweepAngle = 360f * (percentage / 100f),
                useCenter = false,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = stroke, cap = androidx.compose.ui.graphics.StrokeCap.Round)
            )
        }
        Text(text = "$percentage%", style = MaterialTheme.typography.titleLarge)
    }
}
