package com.manoosh.todolist.domain.model

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

enum class RepeatMode { NEVER, DAILY, WEEKLY, MONTHLY, YEARLY }

/**
 * Core task entity used throughout the domain and presentation layers.
 * This is intentionally decoupled from the Room entity (see
 * data.local.entity.TaskEntity) so the UI never depends on persistence
 * details.
 */
data class Task(
    val id: Long = 0L,
    val title: String,
    val description: String = "",
    val createdAt: LocalDateTime = LocalDateTime.now(),
    val updatedAt: LocalDateTime = LocalDateTime.now(),
    val reminderDate: LocalDate? = null,
    val reminderTime: LocalTime? = null,
    val repeatMode: RepeatMode = RepeatMode.NEVER,
    val priority: Priority = Priority.MEDIUM,
    val categoryId: Long? = null,
    val isFavorite: Boolean = false,
    val isCompleted: Boolean = false,
    val isArchived: Boolean = false,
    val backgroundColorHex: String? = null,
    val iconName: String? = null,
    val imageUri: String? = null
) {
    val reminderDateTime: LocalDateTime?
        get() = if (reminderDate != null && reminderTime != null) {
            LocalDateTime.of(reminderDate, reminderTime)
        } else null

    val isOverdue: Boolean
        get() = !isCompleted && reminderDateTime?.isBefore(LocalDateTime.now()) == true
}
