package com.manoosh.todolist.domain.repository

import com.manoosh.todolist.domain.model.Category
import kotlinx.coroutines.flow.Flow

interface CategoryRepository {
    fun observeCategories(): Flow<List<Category>>
    suspend fun getCategoryById(id: Long): Category?
    suspend fun upsertCategory(category: Category): Long
    suspend fun deleteCategory(category: Category)
    suspend fun seedDefaultsIfEmpty()
}
