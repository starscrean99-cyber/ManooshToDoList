package com.manoosh.todolist.presentation.statistics

import java.time.LocalDate

data class DailyCount(val date: LocalDate, val completed: Int, val created: Int)

data class StatisticsUiState(
    val isLoading: Boolean = true,
    val totalTasks: Int = 0,
    val completedTasks: Int = 0,
    val pendingTasks: Int = 0,
    val completionPercentage: Int = 0,
    val todayTasks: Int = 0,
    val categoryBreakdown: Map<String, Int> = emptyMap(),
    val priorityBreakdown: Map<String, Int> = emptyMap(),
    val last7Days: List<DailyCount> = emptyList(),
    val last30DaysCompletionRate: Int = 0
)
