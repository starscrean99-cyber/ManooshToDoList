package com.manoosh.todolist.presentation.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.manoosh.todolist.presentation.home.components.EmptyState
import com.manoosh.todolist.presentation.home.components.FilterChipsRow
import com.manoosh.todolist.presentation.home.components.TaskCard
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onAddTask: () -> Unit,
    onEditTask: (Long) -> Unit,
    onOpenStatistics: () -> Unit,
    onOpenSettings: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var searchExpanded by remember { mutableStateOf(false) }
    var sortMenuExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(uiState.recentlyDeleted) {
        uiState.recentlyDeleted?.let { deleted ->
            scope.launch {
                val result = snackbarHostState.showSnackbar(
                    message = "\"${deleted.title}\" deleted",
                    actionLabel = "Undo",
                    withDismissAction = true
                )
                if (result == SnackbarResult.ActionPerformed) viewModel.onUndoDelete()
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text("Manoosh To Do") },
                actions = {
                    IconButton(onClick = onOpenStatistics) {
                        Icon(Icons.Filled.BarChart, contentDescription = "Statistics")
                    }
                    IconButton(onClick = { searchExpanded = !searchExpanded }) {
                        Icon(Icons.Filled.Search, contentDescription = "Search")
                    }
                    Box {
                        IconButton(onClick = { sortMenuExpanded = true }) {
                            Icon(Icons.Filled.Sort, contentDescription = "Sort")
                        }
                        DropdownMenu(expanded = sortMenuExpanded, onDismissRequest = { sortMenuExpanded = false }) {
                            TaskSort.entries.forEach { sort ->
                                DropdownMenuItem(
                                    text = { Text(sort.name.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }) },
                                    onClick = {
                                        viewModel.onSortSelected(sort)
                                        sortMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = "Settings")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddTask,
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("Add Task") }
            )
        }
    ) { paddingValues ->
        Column(modifier = Modifier.padding(paddingValues)) {

            AnimatedVisibility(visible = searchExpanded) {
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = viewModel::onSearchQueryChanged,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    placeholder = { Text("Search tasks…") },
                    singleLine = true
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            FilterChipsRow(activeFilter = uiState.activeFilter, onFilterSelected = viewModel::onFilterSelected)
            Spacer(modifier = Modifier.height(8.dp))

            if (uiState.isEmpty) {
                EmptyState()
            } else {
                val categoryNameById = uiState.categories.associateBy({ it.id }, { it.name })
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(items = uiState.visibleTasks, key = { it.id }) { task ->
                        TaskCard(
                            task = task,
                            categoryName = task.categoryId?.let { categoryNameById[it] },
                            onClick = { onEditTask(task.id) },
                            onToggleCompleted = { viewModel.onToggleCompleted(task) },
                            onToggleFavorite = { viewModel.onToggleFavorite(task) },
                            onDelete = { viewModel.onDeleteTask(task) },
                            onArchive = { viewModel.onArchiveTask(task) }
                        )
                    }
                    item { Spacer(modifier = Modifier.height(80.dp)) }
                }
            }
        }
    }
}
