package com.manoosh.todolist.data.mapper

import com.manoosh.todolist.data.local.entity.CategoryEntity
import com.manoosh.todolist.data.local.entity.TaskEntity
import com.manoosh.todolist.domain.model.Category
import com.manoosh.todolist.domain.model.Priority
import com.manoosh.todolist.domain.model.RepeatMode
import com.manoosh.todolist.domain.model.Task
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneOffset

fun TaskEntity.toDomain(): Task = Task(
    id = id,
    title = title,
    description = description,
    createdAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(createdAtEpochMillis), ZoneOffset.systemDefault()),
    updatedAt = LocalDateTime.ofInstant(Instant.ofEpochMilli(updatedAtEpochMillis), ZoneOffset.systemDefault()),
    reminderDate = reminderDateEpochDay?.let { LocalDate.ofEpochDay(it) },
    reminderTime = reminderSecondOfDay?.let { LocalTime.ofSecondOfDay(it.toLong()) },
    repeatMode = runCatching { RepeatMode.valueOf(repeatMode) }.getOrDefault(RepeatMode.NEVER),
    priority = runCatching { Priority.valueOf(priority) }.getOrDefault(Priority.MEDIUM),
    categoryId = categoryId,
    isFavorite = isFavorite,
    isCompleted = isCompleted,
    isArchived = isArchived,
    backgroundColorHex = backgroundColorHex,
    iconName = iconName,
    imageUri = imageUri
)

fun Task.toEntity(): TaskEntity {
    val zone = ZoneOffset.systemDefault()
    val reminderMillis = reminderDateTime?.atZone(zone)?.toInstant()?.toEpochMilli()
    return TaskEntity(
        id = id,
        title = title,
        description = description,
        createdAtEpochMillis = createdAt.atZone(zone).toInstant().toEpochMilli(),
        updatedAtEpochMillis = updatedAt.atZone(zone).toInstant().toEpochMilli(),
        reminderDateEpochDay = reminderDate?.toEpochDay(),
        reminderSecondOfDay = reminderTime?.toSecondOfDay(),
        reminderEpochMillis = reminderMillis,
        repeatMode = repeatMode.name,
        priority = priority.name,
        categoryId = categoryId,
        isFavorite = isFavorite,
        isCompleted = isCompleted,
        isArchived = isArchived,
        backgroundColorHex = backgroundColorHex,
        iconName = iconName,
        imageUri = imageUri
    )
}

fun CategoryEntity.toDomain(): Category = Category(
    id = id,
    name = name,
    colorHex = colorHex,
    iconName = iconName,
    isCustom = isCustom
)

fun Category.toEntity(): CategoryEntity = CategoryEntity(
    id = id,
    name = name,
    colorHex = colorHex,
    iconName = iconName,
    isCustom = isCustom
)
