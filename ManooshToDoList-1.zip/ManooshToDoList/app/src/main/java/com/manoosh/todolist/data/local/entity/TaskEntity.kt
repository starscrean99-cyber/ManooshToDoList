package com.manoosh.todolist.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "tasks",
    foreignKeys = [
        ForeignKey(
            entity = CategoryEntity::class,
            parentColumns = ["id"],
            childColumns = ["categoryId"],
            onDelete = ForeignKey.SET_NULL
        )
    ],
    indices = [
        Index("categoryId"),
        Index("isCompleted"),
        Index("isArchived"),
        Index("isFavorite"),
        Index("reminderEpochMillis")
    ]
)
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val description: String,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
    val reminderDateEpochDay: Long?,
    val reminderSecondOfDay: Int?,
    // Denormalized combined instant, indexed for fast "upcoming reminders" queries.
    val reminderEpochMillis: Long?,
    val repeatMode: String,
    val priority: String,
    val categoryId: Long?,
    val isFavorite: Boolean,
    val isCompleted: Boolean,
    val isArchived: Boolean,
    val backgroundColorHex: String?,
    val iconName: String?,
    val imageUri: String?
)
