package com.manoosh.todolist.domain.repository

import com.manoosh.todolist.domain.model.Task
import kotlinx.coroutines.flow.Flow

/**
 * Single source of truth contract for task data. The data layer
 * provides the Room-backed implementation; the domain and presentation
 * layers only ever see this interface.
 */
interface TaskRepository {
    fun observeTasks(): Flow<List<Task>>
    fun observeTaskById(id: Long): Flow<Task?>
    suspend fun getTaskById(id: Long): Task?
    suspend fun upsertTask(task: Task): Long
    suspend fun deleteTask(task: Task)
    suspend fun deleteTasks(taskIds: List<Long>)
    suspend fun setCompleted(taskId: Long, completed: Boolean)
    suspend fun setFavorite(taskId: Long, favorite: Boolean)
    suspend fun setArchived(taskId: Long, archived: Boolean)
}
