package com.manoosh.todolist.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.manoosh.todolist.data.datastore.settingsDataStore
import com.manoosh.todolist.domain.model.AccentColor
import com.manoosh.todolist.domain.model.AppBackground
import com.manoosh.todolist.domain.model.AppFont
import com.manoosh.todolist.domain.model.ManooshThemeModeSetting
import com.manoosh.todolist.domain.model.UserSettings
import com.manoosh.todolist.domain.repository.SettingsRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private object Keys {
    val THEME_MODE = stringPreferencesKey("theme_mode")
    val ACCENT_COLOR = stringPreferencesKey("accent_color")
    val FONT = stringPreferencesKey("font")
    val BACKGROUND = stringPreferencesKey("background")
    val CUSTOM_BG_URI = stringPreferencesKey("custom_bg_uri")
    val NOTIFICATION_SOUND = booleanPreferencesKey("notification_sound")
    val NOTIFICATION_VIBRATION = booleanPreferencesKey("notification_vibration")
    val ANIMATIONS_ENABLED = booleanPreferencesKey("animations_enabled")
    val DYNAMIC_COLOR = booleanPreferencesKey("dynamic_color")
    val LANGUAGE_TAG = stringPreferencesKey("language_tag")
}

@Singleton
class SettingsRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : SettingsRepository {

    override fun observeSettings(): Flow<UserSettings> =
        context.settingsDataStore.data.map { prefs ->
            UserSettings(
                themeMode = prefs[Keys.THEME_MODE]?.let {
                    runCatching { ManooshThemeModeSetting.valueOf(it) }.getOrNull()
                } ?: ManooshThemeModeSetting.SYSTEM,
                accentColor = prefs[Keys.ACCENT_COLOR]?.let {
                    runCatching { AccentColor.valueOf(it) }.getOrNull()
                } ?: AccentColor.BLUE,
                font = prefs[Keys.FONT]?.let {
                    runCatching { AppFont.valueOf(it) }.getOrNull()
                } ?: AppFont.ROBOTO,
                background = prefs[Keys.BACKGROUND]?.let {
                    runCatching { AppBackground.valueOf(it) }.getOrNull()
                } ?: AppBackground.SOLID,
                customBackgroundImageUri = prefs[Keys.CUSTOM_BG_URI],
                notificationSoundEnabled = prefs[Keys.NOTIFICATION_SOUND] ?: true,
                notificationVibrationEnabled = prefs[Keys.NOTIFICATION_VIBRATION] ?: true,
                animationsEnabled = prefs[Keys.ANIMATIONS_ENABLED] ?: true,
                dynamicColorEnabled = prefs[Keys.DYNAMIC_COLOR] ?: true,
                languageTag = prefs[Keys.LANGUAGE_TAG] ?: "en"
            )
        }

    override suspend fun setThemeMode(mode: ManooshThemeModeSetting) {
        context.settingsDataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    override suspend fun setAccentColor(color: AccentColor) {
        context.settingsDataStore.edit { it[Keys.ACCENT_COLOR] = color.name }
    }

    override suspend fun setFont(font: AppFont) {
        context.settingsDataStore.edit { it[Keys.FONT] = font.name }
    }

    override suspend fun setBackground(background: AppBackground, customImageUri: String?) {
        context.settingsDataStore.edit {
            it[Keys.BACKGROUND] = background.name
            if (customImageUri != null) it[Keys.CUSTOM_BG_URI] = customImageUri
        }
    }

    override suspend fun setNotificationSound(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.NOTIFICATION_SOUND] = enabled }
    }

    override suspend fun setNotificationVibration(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.NOTIFICATION_VIBRATION] = enabled }
    }

    override suspend fun setAnimationsEnabled(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.ANIMATIONS_ENABLED] = enabled }
    }

    override suspend fun setDynamicColorEnabled(enabled: Boolean) {
        context.settingsDataStore.edit { it[Keys.DYNAMIC_COLOR] = enabled }
    }

    override suspend fun setLanguageTag(tag: String) {
        context.settingsDataStore.edit { it[Keys.LANGUAGE_TAG] = tag }
    }
}
